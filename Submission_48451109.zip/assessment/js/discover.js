import {initializeButtonAlerts_sub} from './components.js';

initializeButtonAlerts_sub();
window.initializeButtonAlerts_sub = initializeButtonAlerts_sub;